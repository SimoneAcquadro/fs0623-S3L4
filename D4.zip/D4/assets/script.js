const numeriTabellone = [1, 2, 3, 4, 5];
for (let i = 0; i < numeriTabellone.length; i++) {
    const element = numeriTabellone[i];
    const lista = document.createElement("li")
    lista.innerText = "1"
    //document.body.appendChild(lista)
    document.getElementById("lista").appendChild(lista)
}